# mypackage/module1.py
def some_function():
    print("This is a function in module1.")

# mypackage/module2.py
class AnotherClass:
    def do_something(self):
        print("This is a method in AnotherClass.")
