# mypackage/__init__.py
from .module1 import some_function
from .module2 import AnotherClass
